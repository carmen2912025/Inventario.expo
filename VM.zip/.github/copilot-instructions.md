<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

This project is an Expo React Native app for product management with a modern interface and no authentication. Use Expo Router with tabs for navigation. Focus on a fresh, visually distinct UI and clear separation of product, provider, and statistics screens.
