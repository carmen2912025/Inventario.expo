// Configura aquí los datos de tu base de datos MySQL
module.exports = {
  host: 'localhost',
  user: 'root',
  password: 'Fpg*542912*',
  database: 'inventario',
};
