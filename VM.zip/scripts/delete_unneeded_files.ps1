# Elimina archivos vacíos o innecesarios
Remove-Item -Path "j:\Frank\Nueva Carpeta (6)\VM\VM\components\db.ts" -ErrorAction SilentlyContinue
Remove-Item -Path "j:\Frank\Nueva Carpeta (6)\VM\VM\components\mysqlClient.ts" -ErrorAction SilentlyContinue
Remove-Item -Path "j:\Frank\Nueva Carpeta (6)\VM\VM\components\__tests__\mysqlClient-test.ts" -ErrorAction SilentlyContinue
Remove-Item -Path "j:\Frank\Nueva Carpeta (6)\VM\VM\components\useColorScheme.web.ts" -ErrorAction SilentlyContinue
Remove-Item -Path "j:\Frank\Nueva Carpeta (6)\VM\VM\components\useColorScheme.ts" -ErrorAction SilentlyContinue
Remove-Item -Path "j:\Frank\Nueva Carpeta (6)\VM\VM\components\useClientOnlyValue.web.ts" -ErrorAction SilentlyContinue
Remove-Item -Path "j:\Frank\Nueva Carpeta (6)\VM\VM\components\useClientOnlyValue.ts" -ErrorAction SilentlyContinue
Remove-Item -Path "j:\Frank\Nueva Carpeta (6)\VM\VM\types\dbTypes.ts" -ErrorAction SilentlyContinue
Remove-Item -Path "j:\Frank\Nueva Carpeta (6)\VM\VM\types\README.md" -ErrorAction SilentlyContinue
