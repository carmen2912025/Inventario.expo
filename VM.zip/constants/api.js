// API base URL for REST requests
export const API_BASE_URL = 'http://localhost:3001'; // Cambia si usas otro puerto o despliegas en otro host
