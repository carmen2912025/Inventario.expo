// empty module for web
export default {};
